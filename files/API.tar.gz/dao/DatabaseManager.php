<?php

class DatabaseManager
{
    const DATABASE = "AssistApp_DB";
    const USER = "assistapp";
    const PWD = "health123";
    const HOST = "localhost";

    private $pdo;
    private static $instance;

    private function __construct()
    {
        $this->pdo = new PDO("mysql:host=" . self::HOST . ";dbname=" . self::DATABASE . ";charset=utf8mb4", self::USER, self::PWD);

        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    }

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new DatabaseManager();
        }
        return self::$instance;
    }

    public function __destruct()
    {
        $this->pdo = null;
    }

    public function getPDO()
    {
        return $this->pdo;
    }
}

?>