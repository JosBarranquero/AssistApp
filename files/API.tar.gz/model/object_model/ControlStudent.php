<?php

/**
 * Created by PhpStorm.
 * User: amador
 * Date: 11/02/17
 * Time: 16:52
 */
class ControlStudent
{
    var $id;
    var $date;
    var $actitude;
    var $performance;
    var $lack;
    var $student;
    var $coment;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * @param mixed $date
     */
    public function setDate($date)
    {
        $this->date = $date;
    }

    /**
     * @return mixed
     */
    public function getActitude()
    {
        return $this->actitude;
    }

    /**
     * @param mixed $actitude
     */
    public function setActitude($actitude)
    {
        $this->actitude = $actitude;
    }

    /**
     * @return mixed
     */
    public function getPerformance()
    {
        return $this->performance;
    }

    /**
     * @param mixed $performance
     */
    public function setPerformance($performance)
    {
        $this->performance = $performance;
    }

    /**
     * @return mixed
     */
    public function getLack()
    {
        return $this->lack;
    }

    /**
     * @param mixed $lack
     */
    public function setLack($lack)
    {
        $this->lack = $lack;
    }

    /**
     * @return mixed
     */
    public function getStudent()
    {
        return $this->student;
    }

    /**
     * @param mixed $student
     */
    public function setStudent($student)
    {
        $this->student = $student;
    }

    /**
     * @return mixed
     */
    public function getComent()
    {
        return $this->coment;
    }

    /**
     * @param mixed $coment
     */
    public function setComent($coment)
    {
        $this->coment = $coment;
    }

}