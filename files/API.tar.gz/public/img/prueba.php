<?php

echo "hola mundo";