<?php
/*
* 	AssistApp API Config and classes
* Author: José Antonio Barranquero Fernández
*/

define('TABLE_USERS', "Users");
define('TABLE_MESSAGES', "Messages");
define('TABLE_DATA', "MedData");
define('TABLE_RECORD', "MedRecord");
define('TABLE_ASSIST', "assists");

define('CURRENT_VERSION', "Aria");
define('BETA_VERSION', "Concerto");

define('APIKEY', "assistapp");

define('OK', 200);
define('NOT_COMPLETED', 202);
define('FORBIDDEN', 403);
define('CONFLICT', 409);
define('WRONG', 420);
define('OLD_VERSION', 421);
define('NO_NEW_MSG', 430);

class Result
{
    var $code;
    var $status;
    var $message;
    var $users;
    var $meddata;
    var $medrecord;
    var $messages;

    function setCode($c)
    {
        $this->code = $c;
    }

    function getCode()
    {
        return $this->code;
    }

    function setStatus($s)
    {
        $this->status = $s;
    }

    function getStatus()
    {
        return $this->status;
    }

    function setMessage($m)
    {
        $this->message = $m;
    }

    function getMessage()
    {
        return $this->message;
    }

    function getUsers()
    {
        return $this->users;
    }

    function setUsers($users)
    {
        $this->users = $users;
    }

    function getMeddata()
    {
        return $this->meddata;
    }

    function setMeddata($meddata)
    {
        $this->meddata = $meddata;
    }

    function getMedrecord()
    {
        return $this->medrecord;
    }

    function setMedrecord($medrecord)
    {
        $this->medrecord = $medrecord;
    }

    function getMessages()
    {
        return $this->messages;
    }

    function setMessages($messages)
    {
        $this->messages = $messages;
    }
}

class User
{
    var $id;
    var $idDoc;
    var $password;
    var $name;
    var $surname;
    var $type;
    var $img;
    var $email;
	var $apikey;
}

class MedData
{
    var $id;
    var $idPat;
    var $sex;
    var $nationality;
    var $residence;
    var $job;
    var $smoker;
    var $alcohol;
    var $drugs;
}

class MedRecord
{
    var $id;
    var $idData;
    var $reason;
    var $antecedents;
    var $hospitalised;
    var $date;
}

class Message
{
    var $id;
    var $content;
    var $sender;
    var $receiver;
    var $date;
}

class Email
{
    var $from;
    var $password;
    var $to;
    var $subject;
    var $message;
}

?>
