<?php

// Routes

/*
$app->get('/[{name}]', function ($request, $response, $args) {
    // Sample log message
    $this->logger->info("Slim-Skeleton '/' route");

    // Render index view
    return $this->renderer->render($response, 'index.phtml', $args);
});
*/

$app->get("/", function ($request, $response) {

    $this->response->withHeader('Content-type', 'text/html; charset=UTF-8');
    return $this->response->write(
        "<h1>AssistApp RESTful API Slim - by BitBits</h1>
		<a href ='doc/index.html'>API Documentation</a>");
});

// check if user exists, and return it
$app->post('/user', function ($request, $response) {
    $result = new Result();

    $key = $request->getHeader('apikey');

    if ($key[0] != "assistapp") {
        $result->setCode(FALSE);
        $result->setStatus(403);
        $result->setMessage("Forbbiden");
    } else {
        try {
            $input = $request->getParsedBody();

            $dbquery = $this->db->prepare("SELECT * FROM ".TABLE_USERS." WHERE idDoc LIKE ? AND password = SHA2(?, 256)");
            $dbquery->bindParam(1, $input['idDoc']);
            $dbquery->bindParam(2, $input['password']);
            $dbquery->execute();
            $user = $dbquery->fetchAll();

            if ($user != null) {
                $result->setCode(TRUE);
                $result->setStatus(OK);
                $result->setUsers($user);
            } else {
                $result->setCode(FALSE);
                $result->setStatus(WRONG);
                $result->setMessage("Incorrect user or password");
            }
        } catch (PDOException $e) {
            $result->setCode(FALSE);
            $result->setStatus(CONFLICT);
            $result->setMessage("Error: " . $e->getMessage());
        }
    }
    return $this->response->withJson($result);
});

// get medical data
$app->get('/meddata/[{id_pat}]', function ($request, $response, $args) {
    $result = new Result();

    $key = $request->getHeader('apikey');

    if ($key[0] != "assistapp") {
        $result->setCode(FALSE);
        $result->setStatus(403);
        $result->setMessage("Forbbiden");
    } else {
        try {
            $dbquery = $this->db->prepare("SELECT * FROM " . TABLE_DATA . " WHERE idPat = :idPat");
            $dbquery->bindParam(":idPat", $args['idPat']);
            $dbquery->execute();
            $meddata = $dbquery->fetchAll();

            $result->setCode(TRUE);
            $result->setStatus(OK);
            $result->setMedData($meddata);
        } catch (PDOException $e) {
            $result->setCode(FALSE);
            $result->setStatus(CONFLICT);
            $result->setMessage("Error: " . $e->getMessage());
        }
    }

    return $this->response->withJson($result);
});

$app->get('/medrecord/[{id_data}]', function ($request, $response, $args) {
    $result = new Result();

    $key = $request->getHeader('apikey');

    if ($key[0] != "assistapp") {
        $result->setCode(FALSE);
        $result->setStatus(403);
        $result->setMessage("Forbbiden");
    } else {
        try {
            $dbquery = $this->db->prepare("SELECT * FROM " . TABLE_RECORD . " WHERE idData = :idData");
            $dbquery->bindParam(":idData", $args['idData']);
            $dbquery->execute();
            $medrecord = $dbquery->fetchAll();

            $result->setCode(TRUE);
            $result->setStatus(OK);
            $result->setMedRecord($medrecord);
        } catch (PDOException $e) {
            $result->setCode(FALSE);
            $result->setStatus(CONFLICT);
            $result->setMessage("Error: " . $e->getMessage());
        }
    }

    return $this->response->withJson($result);
});

//select distinct * from assists where id_pat = 1 or id_nur = 1;
$app->get('/assist/[{id}]', function ($request, $response, $args) {
    $result = new Result();

    $key = $request->getHeader('apikey');

    if ($key[0] != "assistapp") {
        $result->setCode(FALSE);
        $result->setStatus(403);
        $result->setMessage("Forbbiden");
    } else {
        try {
            //$dbquery = $this->db->prepare("SELECT DISTINCT CONCAT(u.name, ' ', u.surname) as name, u.img as img, u.id as id FROM " .TABLE_USERS . "u INNER JOIN " . TABLE_ASSIST . " a ON u.id = a.id_pat WHERE a.id_nur = :id");
            $dbquery = $this->db->prepare("SELECT DISTINCT * FROM " . TABLE_USERS . " u INNER JOIN " . TABLE_ASSIST . " a ON u.id = a.idPat WHERE a.idNur = :id");
            $dbquery->bindParam(":id", $args['id']);
            $dbquery->execute();

            if ($dbquery->rowCount() < 1) {    //If this happens, this means the user is a nurse, and we have to look for patients
                $dbquery = $this->db->prepare("SELECT DISTINCT * FROM " . TABLE_USERS . " u INNER JOIN " . TABLE_ASSIST . " a ON u.id = a.idNur WHERE a.idPat = :id");
                $dbquery->bindParam(":id", $args['id']);
                $dbquery->execute();
            }
            $assist = $dbquery->fetchAll();

            $result->setCode(TRUE);
            $result->setStatus(OK);
            $result->setUsers($assist);
        } catch (PDOException $e) {
            $result->setCode(FALSE);
            $result->setStatus(CONFLICT);
            $result->setMessage("Error: " . $e->getMessage());
        }
    }

    return $this->response->withJson($result);
});

$app->post('/messages', function ($request, $response) {
    $result = new Result();

    $key = $request->getHeader('apikey');

    if ($key[0] != "assistapp") {
        $result->setCode(FALSE);
        $result->setStatus(403);
        $result->setMessage("Forbbiden");
    } else {
        try {
            $input = $request->getParsedBody();

            $dbquery = $this->db->prepare("SELECT * FROM " . TABLE_MESSAGES . " WHERE (sender = :sender AND receiver = :receiver) OR (sender = :receiver AND receiver = :sender)");
            $dbquery->bindParam(":receiver", $input['receiver']);
            $dbquery->bindParam(":sender", $input['sender']);
            $dbquery->execute();

            $messages = $dbquery->fetchAll();

            $result->setCode(TRUE);
            $result->setStatus(OK);
            $result->setMessages($messages);
        } catch (PDOException $e) {
            $result->setCode(FALSE);
            $result->setStatus(CONFLICT);
            $result->setMessage("Error: " . $e->getMessage());
        }
    }
    return $this->response->withJson($result);
});

$app->post('/message', function ($request, $response) {

    $result = new Result();

    $key = $request->getHeader('apikey');

    if ($key[0] != "assistapp") {
        $result->setCode(FALSE);
        $result->setStatus(403);
        $result->setMessage("Forbbiden");
    } else {
        //lock the table
        try {
            $input = $request->getParsedBody();
            $dbquery = $this->db->prepare("INSERT INTO " . TABLE_MESSAGES . " (content, sender, receiver, date) SELECT :content, :sender, :receiver, NOW()");
            $dbquery->bindParam(":content", $input['content']);
            $dbquery->bindParam(":sender", $input['sender']);
            $dbquery->bindParam(":receiver", $input['receiver']);
            $dbquery->execute();
            $number = $dbquery->rowCount();
            if ($number > 0) {
                $result->setCode(TRUE);
                $result->setStatus(OK);
            } else {
                $result->setCode(FALSE);
                $result->setStatus(NOT_COMPLETED);
                $result->setMessage("NOT INSERTED");
            }
        } catch (PDOException $e) {
            $result->setCode(FALSE);
            $result->setStatus(CONFLICT);
            $result->setMessage("Error: " . $e->getMessage());
        }
    }
    return $this->response->withJson($result);
});

$app->post("/email", function ($request, $response) {
    $result = new Result();
    $key = $request->getHeader('apikey');

    if ($key[0] != "assistapp") {
        $result->setCode(FALSE);
        $result->setStatus(403);
        $result->setMessage("Forbbiden");
    } else {
        $input = $request->getParsedBody();
        $result = sendEmail($input['from'], $input['password'], $input['to'], $input['subject'], $input['message']);
    }
    return $this->response->withJson($result);
});

function sendEmail($from, $password, $to, $subject, $message)
{

    $result = new Result();
    $mail = new PHPMailer(true);    // the true param means it will throw exceptions on errors, which we need to catch
    $mail->IsSMTP();        // telling the class to use SMTP

    try {
        $mail->SMTPDebug = 2;            // enables SMTP debug information (for testing)
        //$mail->SMTPDebug  = 0;
        $mail->SMTPAuth = true;            // enable SMTP authentication
        $mail->SMTPSecure = "None";                    // sets the prefix to the server
        $mail->Host = "mail.portadaalta.info";
        //$mail->Host       = "smtp.gmail.com";      	// sets GMAIL as the SMTP server
        //$mail->Host       = "smtp.openmailbox.org";
        $mail->Port = 25;                    // set the SMTP port for the GMAIL server
        $mail->Username = $from;            // GMAIL username
        $mail->Password = $password;        // GMAIL password
        $mail->AddAddress($to);            // Receiver email
        $mail->SetFrom($from, 'Jose Barranquero');        // email sender
        $mail->AddReplyTo($from, 'Jose Barranquero');        // email to reply
        $mail->Subject = $subject;            // subject of the message
        $mail->AltBody = 'Message in plain text';    // optional - MsgHTML will create an alternate automatically
        $mail->MsgHTML($message);            // message in the email
        //$mail->AddAttachment('images/phpmailer.gif');      // attachment
        $mail->Send();
        $result->setCode(TRUE);
        $result->setMessage("Message Sent OK to " . $to);
    } catch (phpmailerException $e) {
        //echo $e->errorMessage(); 			//Pretty error messages from PHPMailer
        $result->setCode(FALSE);
        $result->setMessage("Error: " . $e->errorMessage());
    } catch (Exception $e) {
        //echo $e->getMessage(); 			//Boring error messages from anything else!
        $result->setCode(FALSE);
        $result->setMessage("Error: " . $e->getMessage());
    }
    return $result;
}

$app->get('/absence', function ($request, $response) {
    $result = new Result();

    $key = $request->getHeader('apikey');

    if ($key[0] != "assistapp") {
        $result->setCode(FALSE);
        $result->setStatus(403);
        $result->setMessage("Forbbiden");
    } else {
        try {
            $dbquery = $this->db->prepare("SELECT a.id, a.student, a.absence, a.work, a.attitude, a.remarks FROM " . TABLE_ABSENCES . " a WHERE a.date = CURDATE()");
            $dbquery->execute();
            $absences = $dbquery->fetchAll();

            $result->setCode(TRUE);
            $result->setStatus(OK);
            $result->setAbsences($absences);
        } catch (PDOException $e) {
            $result->setCode(FALSE);
            $result->setStatus(CONFLICT);
            $result->setMessage("Error: " . $e->getMessage());
        }
    }
    return $this->response->withJson($result);
});

$app->put('/absence/[{id}]', function ($request, $response, $args) {

    $result = new Result();

    $key = $request->getHeader('apikey');

    if ($key[0] != "assistapp") {
        $result->setCode(FALSE);
        $result->setStatus(403);
        $result->setMessage("Forbbiden");
    } else {
        try {
            $input = $request->getParsedBody();
            $dbquery = $this->db->prepare("UPDATE " . TABLE_ABSENCES . " SET absence = ?, work = ?, attitude = ?, remarks = ? WHERE id = ?");
            $dbquery->bindParam(1, $input['absence']);
            $dbquery->bindParam(2, $input['work']);
            $dbquery->bindParam(3, $input['attitude']);
            $dbquery->bindParam(4, $input['remarks']);
            $dbquery->bindParam(5, $input['id']);
            $dbquery->execute();
            $number = $dbquery->rowCount();

            if ($number > 0) {
                $result->setCode(TRUE);
                $result->setStatus(OK);
            } else {
                $result->setCode(FALSE);
                $result->setStatus(NOT_COMPLETED);
                $result->setMessage("NOT UPDATED");
            }
        } catch (PDOException $e) {
            $result->setCode(FALSE);
            $result->setStatus(CONFLICT);
            $result->setMessage("Error: " . $e->getMessage());
        }
    }
    return $this->response->withJson($result);
});
