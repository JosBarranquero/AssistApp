<?php
/*
* 	AssistApp API Routes
* Author: José Antonio Barranquero Fernández
*/

$app->get("/", function ($request, $response) {

    $this->response->withHeader('Content-type', 'text/html; charset=UTF-8');
    return $this->response->write(
        "<h1>AssistApp RESTful API Slim - by BitBits</h1>
		<a href ='doc/index.html'>API Documentation</a>");
});

// Login: check if user exists, and return it
$app->post('/user', function ($request, $response) {
    $result = new Result();

    $key = $request->getHeader('apikey')[0];
    $userId = $request->getHeader('userId')[0];
    $version = $request->getHeader('codename')[0];

    if (($version != CURRENT_VERSION) && ($version != BETA_VERSION) && ($key != APIKEY)) {  // We only show the message to update when the apikey isn't the default one
        $result->setCode(FALSE);
        $result->setStatus(OLD_VERSION);
        $result->setMessage("Please, update");
    } else {
        if (($key != APIKEY) && (!checkApikey($key, $userId))) {
            $result->setCode(FALSE);
            $result->setStatus(FORBIDDEN);
            $result->setMessage("Forbidden");
        } else {
            try {
                $db = DatabaseManager::getInstance()->getPDO();
                $input = $request->getParsedBody();

                $dbquery = $db->prepare("SELECT * FROM " . TABLE_USERS . " WHERE idDoc LIKE ? AND password = SHA2(?, 256)");
                $dbquery->bindParam(1, $input['idDoc']);
                $dbquery->bindParam(2, $input['password']);
                $dbquery->execute();
                $user = $dbquery->fetchAll();

                if ($user != null) {
                    $activequery = $db->prepare("SELECT * FROM " . TABLE_USERS . " WHERE idDoc LIKE ? AND active = TRUE");
                    $activequery->bindParam(1, $input['idDoc']);
                    $activequery->execute();
                    $active = $activequery->fetchAll();

                    if ($active != null) {
                        $result->setCode(TRUE);
                        $result->setStatus(OK);
                        $result->setUsers($active);
                    } else {
                        $result->setCode(FALSE);
                        $result->setStatus(INACTIVE);
                    }
                } else {
                    $result->setCode(FALSE);
                    $result->setStatus(WRONG_CREDENTIALS);
                    $result->setMessage("Incorrect user or password");
                }
            } catch (PDOException $e) {
                $result->setCode(FALSE);
                $result->setStatus(CONFLICT);
                $result->setMessage("Error: " . $e->getMessage());
            }
        }
    }
    return $this->response->withJson($result);
});

// Update user password and email
$app->put('/user', function ($request, $response) {
    $result = new Result();

    $key = $request->getHeader('apikey')[0];
    $userId = $request->getHeader('userId')[0];

    if (!checkApikey($key, $userId)) {
        $result->setCode(FALSE);
        $result->setStatus(FORBIDDEN);
        $result->setMessage("Forbidden");
    } else {
        try {
            $db = DatabaseManager::getInstance()->getPDO();
            $input = $request->getParsedBody();

            $dbquery = $db->prepare("UPDATE " . TABLE_USERS . " SET password = SHA2(?, 256), email = ? WHERE id = ?");
            $dbquery->bindParam(1, $input['password']);
            $dbquery->bindParam(2, $input['email']);
            $dbquery->bindParam(3, $input['id']);
            $dbquery->execute();
            $number = $dbquery->rowCount();

            if ($number > 0) {
                $result->setCode(TRUE);
                $result->setStatus(OK);
                $result->setMessage($number . " rows affected");
            } else {
                $result->setCode(FALSE);
                $result->setStatus(NOT_COMPLETED);
                $result->setMessage("Problem updating user");
            }
        } catch (PDOException $e) {
            $result->setCode(FALSE);
            $result->setStatus(CONFLICT);
            $result->setMessage("Error: " . $e->getMessage());
        }
    }
    return $this->response->withJson($result);
});

// Get Medical Data
$app->get('/meddata/[{idPat}]', function ($request, $response, $args) {
    $result = new Result();

    $key = $request->getHeader('apikey')[0];
    $userId = $request->getHeader('userId')[0];

    if (!checkApikey($key, $userId)) {
        $result->setCode(FALSE);
        $result->setStatus(FORBIDDEN);
        $result->setMessage("Forbidden");
    } else {
        try {
            $db = DatabaseManager::getInstance()->getPDO();

            $dbquery = $db->prepare("SELECT * FROM " . TABLE_DATA . " WHERE idPat = :idPat");
            $dbquery->bindParam(":idPat", $args['idPat']);
            $dbquery->execute();
            $meddata = $dbquery->fetchAll();

            if ($meddata != null) {
                $result->setCode(TRUE);
                $result->setStatus(OK);
                $result->setMedData($meddata);
            } else {
                $result->setCode(FALSE);
                $result->setStatus(WRONG_CREDENTIALS);
                $result->setMessage("No data available");
            }
        } catch (PDOException $e) {
            $result->setCode(FALSE);
            $result->setStatus(CONFLICT);
            $result->setMessage("Error: " . $e->getMessage());
        }
    }

    return $this->response->withJson($result);
});

// Get Medical Record
$app->get('/medrecord/[{idData}]', function ($request, $response, $args) {
    $result = new Result();

    $key = $request->getHeader('apikey')[0];
    $userId = $request->getHeader('userId')[0];

    if (!checkApikey($key, $userId)) {
        $result->setCode(FALSE);
        $result->setStatus(FORBIDDEN);
        $result->setMessage("Forbidden");
    } else {
        try {
            $db = DatabaseManager::getInstance()->getPDO();

            $dbquery = $db->prepare("SELECT * FROM " . TABLE_RECORD . " WHERE idData = :idData");
            $dbquery->bindParam(":idData", $args['idData']);
            $dbquery->execute();
            $medrecord = $dbquery->fetchAll();

            $result->setCode(TRUE);
            $result->setStatus(OK);
            $result->setMedRecord($medrecord);

        } catch (PDOException $e) {
            $result->setCode(FALSE);
            $result->setStatus(CONFLICT);
            $result->setMessage("Error: " . $e->getMessage());
        }
    }

    return $this->response->withJson($result);
});

// Get Assistances
$app->get('/assist/[{id}]', function ($request, $response, $args) {
    $result = new Result();

    $key = $request->getHeader('apikey')[0];
    $userId = $request->getHeader('userId')[0];

    if (!checkApikey($key, $userId)) {
        $result->setCode(FALSE);
        $result->setStatus(FORBIDDEN);
        $result->setMessage("Forbidden");
    } else {
        try {
            $db = DatabaseManager::getInstance()->getPDO();

            $dbquery = $db->prepare("SELECT DISTINCT * FROM " . TABLE_USERS . " u INNER JOIN " . TABLE_ASSIST . " a ON u.id = a.idPat WHERE a.idNur = :id ORDER BY u.name");
            $dbquery->bindParam(":id", $args['id']);
            $dbquery->execute();

            if ($dbquery->rowCount() < 1) {    //If this happens, this means the user is a nurse, and we have to look for patients
                $dbquery = $db->prepare("SELECT DISTINCT * FROM " . TABLE_USERS . " u INNER JOIN " . TABLE_ASSIST . " a ON u.id = a.idNur WHERE a.idPat = :id ORDER BY u.name");
                $dbquery->bindParam(":id", $args['id']);
                $dbquery->execute();
            }
            $assist = $dbquery->fetchAll();

            $result->setCode(TRUE);
            $result->setStatus(OK);
            $result->setUsers($assist);
        } catch (PDOException $e) {
            $result->setCode(FALSE);
            $result->setStatus(CONFLICT);
            $result->setMessage("Error: " . $e->getMessage());
        }
    }

    return $this->response->withJson($result);
});

// Get Messages for user with id [{id}]
$app->get('/messages/[{id}]', function ($request, $response, $args) {
    $result = new Result();

    $key = $request->getHeader('apikey')[0];
    $userId = $request->getHeader('userId')[0];
    $version = $request->getHeader('codename')[0];

    if (!checkApikey($key, $userId)) {
        $result->setCode(FALSE);
        $result->setStatus(FORBIDDEN);
        $result->setMessage("Forbidden");
    } else {
        if (($version != CURRENT_VERSION) && ($version != BETA_VERSION)) {
            $result->setCode(FALSE);
            $result->setStatus(OLD_VERSION);
            $result->setMessage("Please, update");
        } else {
            try {
                $db = DatabaseManager::getInstance()->getPDO();

                $dbquery = $db->prepare("SELECT * FROM " . TABLE_MESSAGES . " WHERE receiver = :receiver AND `read` = 0 ORDER BY date");
                $dbquery->bindParam(":receiver", $args['id']);
                $dbquery->execute();

                if ($dbquery->rowCount() < 1) {    //If this happens, this means there are no new messages
                    $result->setCode(FALSE);
                    $result->setStatus(NO_NEW_MSG);
                    $result->setMessage("No new messages");
                } else {                            // There are new messages
                    $messages = $dbquery->fetchAll();

                    $result->setCode(TRUE);
                    $result->setStatus(OK);
                    $result->setMessages($messages);
                }
            } catch (PDOException $e) {
                $result->setCode(FALSE);
                $result->setStatus(CONFLICT);
                $result->setMessage("Error: " . $e->getMessage());
            }
        }
    }

    return $this->response->withJson($result);
});

// Get Messages between sender and receiver
$app->post('/messages', function ($request, $response) {
    $result = new Result();

    $key = $request->getHeader('apikey')[0];
    $userId = $request->getHeader('userId')[0];

    if (!checkApikey($key, $userId)) {
        $result->setCode(FALSE);
        $result->setStatus(FORBIDDEN);
        $result->setMessage("Forbidden");
    } else {
        try {
            $db = DatabaseManager::getInstance()->getPDO();
            $input = $request->getParsedBody();

            $dbquery = $db->prepare("SELECT * FROM " . TABLE_MESSAGES . " WHERE (sender = :sender AND receiver = :receiver) OR (sender = :receiver AND receiver = :sender) ORDER BY date");
            $dbquery->bindParam(":receiver", $input['receiver']);
            $dbquery->bindParam(":sender", $input['sender']);
            $dbquery->execute();

            $messages = $dbquery->fetchAll();

            $result->setCode(TRUE);
            $result->setStatus(OK);
            $result->setMessages($messages);

            $readquery = $db->prepare("UPDATE " . TABLE_MESSAGES . " SET `read` = 1 WHERE (receiver = :sender AND sender = :receiver)");
            $readquery->bindParam(":receiver", $input['receiver']);
            $readquery->bindParam(":sender", $input['sender']);
            $readquery->execute();
        } catch (PDOException $e) {
            $result->setCode(FALSE);
            $result->setStatus(CONFLICT);
            $result->setMessage("Error: " . $e->getMessage());
        }
    }
    return $this->response->withJson($result);
});

// Send a new Message from sender to receiver
$app->put('/messages', function ($request, $response) {
    $result = new Result();

    $key = $request->getHeader('apikey')[0];
    $userId = $request->getHeader('userId')[0];

    if (!checkApikey($key, $userId)) {
        $result->setCode(FALSE);
        $result->setStatus(FORBIDDEN);
        $result->setMessage("Forbidden");
    } else {
        try {
            $db = DatabaseManager::getInstance()->getPDO();
            $input = $request->getParsedBody();

            $dbquery = $db->prepare("INSERT INTO " . TABLE_MESSAGES . " (content, sender, receiver, date) SELECT :content, :sender, :receiver, NOW()");
            $dbquery->bindParam(":content", $input['content']);
            $dbquery->bindParam(":sender", $input['sender']);
            $dbquery->bindParam(":receiver", $input['receiver']);
            $dbquery->execute();
            $number = $dbquery->rowCount();
            if ($number > 0) {
                $result->setCode(TRUE);
                $result->setStatus(OK);
            } else {
                $result->setCode(FALSE);
                $result->setStatus(NOT_COMPLETED);
                $result->setMessage("NOT INSERTED");
            }
        } catch (PDOException $e) {
            $result->setCode(FALSE);
            $result->setStatus(CONFLICT);
            $result->setMessage("Error: " . $e->getMessage());
        }
    }
    return $this->response->withJson($result);
});

// Fuction which checks if $apikey is recorded in the database
function checkApikey($apikey, $userId)
{
    $valid = false;
    $db = DatabaseManager::getInstance()->getPDO();

    $dbquery = $db->prepare("SELECT * FROM " . TABLE_USERS . " WHERE apikey LIKE :apikey AND id = :userId");
    $dbquery->bindParam(":apikey", $apikey);
    $dbquery->bindParam(":userId", $userId);
    $dbquery->execute();

    if ($dbquery->rowCount() != 0) {        // If there is less than a record, it's not a valid apikey
        $valid = true;
    }

    return $valid;
}
