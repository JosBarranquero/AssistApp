<?php 
include_once('php/app.php');
global $app;
$app = new App();
if (!$app->isLogged()) {
	// If the user is not logged, he or she is redirected to the login
	header('Location: ./php/login.php');
} else {
	// Otherwise, he or she is redirected to the users list
	header('Location: ./php/users.php');
}
?>
