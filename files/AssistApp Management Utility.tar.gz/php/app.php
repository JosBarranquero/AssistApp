<?php
include('dao.php');

class App
{
    protected $dao;

    function head($title = "", $h1 = "", $h2 = null)
    {
        echo "
		  <!DOCTYPE html>
		  <html lang=\"es\">
  			   <head>
    			    <meta charset=\"utf-8\" />
    			    <title>$title</title>
    			    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />
    			    
					<link rel=\"stylesheet\" type=\"text/css\" href=\"../css/style.css\" />

					<!-- BOOTSTRAP -->
					<link rel=\"stylesheet\" type=\"text/css\" href=\"../css/bootstrap.min.css\" media=\"screen\" />

                    <link rel=\"icon\" type=\"image/png\" href=\"../img/logo.png\"/>
					</head>

					<body>

					<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src=\"../js/bootstrap.min.js\"></script>
	
  				    <!--Header-->
    		      	<header>
    	   		      	<h1>$h1</h1>
        				<h2>$h2</h2>
        			</header>";
    }

    function nav()
    {
        if ($this->isLogged()) {

            echo "<!--Menu-->
    			     <nav>
    				    <ul>
							<li><a href=\"users.php\"><img src=\"/AssistApp/img/users.png\"/>Users</a></li>
							<li><a href=\"meddata.php\"><img src=\"/AssistApp/img/meddata.png\"/>Medical Data</a></li>
							<li><a href=\"medrecord.php\"><img src=\"/AssistApp/img/medrecord.png\"/>Medical Record</a></li>
							<li><a href='assist.php'><img src='/AssistApp/img/assistance.png'/>Assistance</a></li>
							<li><a href=\"logout.php\"><img src=\"/AssistApp/img/disconnect.png\"/>Log out</a></li>
        				</ul>
    			 </nav>
    			 <div id=\"content\"><center>";
        } else {
            echo "<!--Menu-->
    			     <nav>
    				    <ul>
							<li><a href=\"login.php\"><img src=\"/AssistApp/img/connect.png\"/>Log in</a></li>
        				</ul>
    			 </nav>
    			 <div id=\"content\"><center>";
        }
    }

    function foot()
    {
        echo "</center>
		  </div>
	       <footer class=\"footer\">
    	   <p class=\"text-muted\"><a href=\"https://bitbits.hopto.org\" target=\"_blank\" rel=\"nofollow\">BitBits</a></p>
    	   </footer>
  		    </body>
	       	</html>";
    }

    function __construct()
    {
        $this->dao = new AssistAppDao();
    }

    /* Method which is called in every php that needs a session */
    function start_session()
    {
        session_start();
        if (!$this->isLogged())
            header('Location: login.php');
    }

    /* Method which initialises the session by setting the SESSION variable called user */
    function init_session($user)
    {
        if (!isset($_SESSION['user']))
            $_SESSION['user'] = $user;
    }

    /* Method which unsets the SESSION variable called user, destroys the session, and returns to index.php */
    function destroy_session()
    {
        if (isset($_SESSION['user']))
            unset($_SESSION['user']);
        session_destroy();
        header('Location: ../index.php');
    }

    function isConnected() {
        return $this->dao->isConnected();
    }

    /* Method which prints to screen the DAO error */
    function showErrorConnection()
    {
        echo "<p>" . $this->dao->getError() . "</p>";
    }

    /* Method which checks if the user is logged in, by checking whether the SESSION variable called user is set */
    function isLogged()
    {
        return isset($_SESSION['user']);
    }

    /* Function which uploads the image to the profiles/ directory */
    function upload($img) {
        //create uploads and put permissions
        $target_dir = "../profiles/";
        $target_file = $target_dir . basename($img["name"]);
        $uploadOk = true;
        $FileType = pathinfo($target_file, PATHINFO_EXTENSION);

        // Check if file already exists
        if (file_exists($target_file)) {
            $uploadOk = false;
        } // Check file size bigger than 64 kb
        else if ($img["size"] > 65536) {
            $uploadOk = false;
        } // Allow certain file formats: JPG, PNG or GIF
        else if ($FileType != "jpg" && $FileType != "png" && $FileType != "gif") {
            $uploadOk = false;
        }
        if ($uploadOk) {
            if (!move_uploaded_file($img["tmp_name"], $target_file)) {
                $uploadOk = false;
            }
        }
        return $uploadOk;
    }


    /* Function which checks whether the password is at least 8 characters long and has alphanumeric characters */
    function checkPass($password) {
        return preg_match( '/[^A-Za-z0-9]+/', $password) || strlen( $password) >= 8;
    }

    /* Method which returns the current user id_doc */
    function getCurrentUserIdDoc()
    {
        if ($this->isLogged())
            return $_SESSION['user'];
    }

    /* Method which returns all the users */
    function getAllUsers() {
        return $this->dao->getAllUsers();
    }

    function getAllPatientsNames() {
        return $this->dao->getAllPatientsNames();
    }

    function getAllNursesNames() {
        return $this->dao->getAllNursesNames();
    }

    /* Method which gets the user id */
    function getUserByDoc($id_doc) {
        return $this->dao->getUserByDoc($id_doc);
    }

    function getUserDocById($id) {
        return $this->dao->getUserDocById($id);
    }

    /* This functions checks if a user already exists in our database */
    function containsUser($user) {
        return $this->dao->containsUser($user);
    }

    function insertUser($doc, $pass, $name, $surname, $type, $img, $email) {
        return $this->dao->insertUser($doc, $pass, $name, $surname, $type, $img, $email);
    }

    function updateUser($oldid, $pass, $name, $surname, $type, $img, $email) {
        return $this->dao->updateUser($oldid, $pass, $name, $surname, $type, $img, $email);
    }

    /* This function checks if the credentials entered in the login screen are correct and if the user is a nurse */
    function checkUser($id_doc, $password) {
        return $this->dao->checkUser($id_doc, $password);
    }

    function checkPrivileges($id_doc)
    {
        return $this->dao->checkPrivileges($id_doc);
    }




    function getAllMedData() {
        return $this->dao->getAllMedData();
    }

    function getAllMedDataNames() {
        return $this->dao->getAllMedDataNames();
    }

    function getDataById($id) {
        return $this->dao->getDataById($id);
    }

    function insertData($pat, $sex, $nationality, $birthdate, $residence, $job, $smoker, $alcohol, $drugs) {
        return $this->dao->insertData($pat, $sex, $nationality, $birthdate, $residence, $job, $smoker, $alcohol, $drugs);
    }

    function updateData($oldid, $sex, $nationality, $birthdate, $residence, $job, $smoker, $alcohol, $drugs) {
        return $this->dao->updateData($oldid, $sex, $nationality, $birthdate, $residence, $job, $smoker, $alcohol, $drugs);
    }




    function getAllMedRecord() {
        return $this->dao->getAllMedRecord();
    }

    function insertRecord($data, $reason, $antecedents, $hospitalised) {
        return $this->dao->insertRecord($data, $reason, $antecedents, $hospitalised);
    }

    function deleteMedRecord($id) {
        return $this->dao->deleteMedRecord($id);
    }




    function getAllAssistance() {
        return $this->dao->getAllAssistance();
    }

    function insertAssistance($id_pat, $id_nur) {
        return $this->dao->insertAssistance($id_pat, $id_nur);
    }

    function deleteAssistance($id_pat, $id_nur) {
        return $this->dao->deleteAssistance($id_pat, $id_nur);
    }
}

?>