<?php
include_once ('app.php');
global $app;
$app = new App();
$app->start_session();
$app->head("AssistApp - Nurse Assistance", "AssistApp Management Utility", "Nurse Assistance Management");
$app->nav();

if (isset($_GET['query'])) {    //If 'query' is set, this means we want to search for something
    $statement = $app->searchAssistance($_GET['query']);
} else {                        //Else, we just want the complete listing
    $statement = $app->getAllAssistance();
}

// Search form
echo "<form action='".$_SERVER['PHP_SELF']."' method='GET' class='form-inline'>";
echo "<input type='text' name='query' placeholder='Search query' class='form-control'/>";
echo "<input type=\"image\" src='/AssistApp/img/search.png' alt='Search' class=\"btn btn-success\"/>";
echo "</form><br/>";

if (!$statement) {  // If there was an error getting the listing, we print it
    $app->showErrorConnection();
} else if (count($result = $statement->fetchAll()) == 0) {  // If there is no nurse assistance
    echo "<p>No nurses assisting...</p>";
} else {                                                // If there is, we show a table
    echo "<table class=\"table table-striped\">";
    echo "<tr>";
    for ($i = 0; $i < $statement->columnCount(); $i++) {
        $columnMeta = $statement->getColumnMeta($i);
        echo "<th>" . $columnMeta['name'] . "</th>";
        if ($i == $statement->columnCount() - 3) {   // We add another column at the last position
            echo "<th>delete</th>";
            $i = $statement->columnCount();
        }

    }
    echo "</tr>";

    foreach ($result as $row) {
        echo "<tr>";
        for ($i=0; $i < $statement->columnCount(); $i++) {
            echo "<td>".$row[$i]."</td>";
            if ($i == $statement->columnCount()-3) {    // We add the delete button in the last column
                echo "<td>
                        <a href=\"assistman.php?id_pat=".$row[ASSIST_PAT]."&id_nur=".$row[ASSIST_NUR]."\"><img src=\"/AssistApp/img/delete.png\"></a>
                      </td>";
                $i = $statement->columnCount();
            }
        }
        echo "</tr>";
    }
    echo "</table>";
}

// Add new assistance option
echo "<p><a href='assistman.php'><img src='/AssistApp/img/assistancenew.png'/>Add new assistance</a></p>";

$app->foot();
?>
