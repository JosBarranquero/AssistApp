<?php
include_once ('app.php');
global $app;
$app = new App();
$app->start_session();
$app->head("AssistApp - Nurse Assistance", "AssistApp Management Utility", "Nurse Assistance Management");
$app->nav();

$statement = $app->getAllAssistance();

if (!$statement) {
    $app->showErrorConnection();
} else if (count($result = $statement->fetchAll()) == 0) {
    echo "<p>No nurses assisting...</p>";   /* This should not appear */
} else {
    echo "<table class=\"table table-striped\">";
    echo "<tr>";
    for ($i = 0; $i < $statement->columnCount(); $i++) {
        $columnMeta = $statement->getColumnMeta($i);
        echo "<th>" . $columnMeta['name'] . "</th>";
        if ($i == $statement->columnCount() - 3) {   /* We add another column at the last position */
            echo "<th>delete</th>";
            $i = $statement->columnCount();
        }

    }
    echo "</tr>";

    foreach ($result as $row) {
        echo "<tr>";
        for ($i=0; $i < $statement->columnCount(); $i++) {
            echo "<td>".$row[$i]."</td>";
            if ($i == $statement->columnCount()-3) {    /* We add the edit button in the last column */
                echo "<td>
                        <a href=\"assistman.php?id_pat=".$row[ASSIST_PAT]."&id_nur=".$row[ASSIST_NUR]."\"><img src=\"/AssistApp/img/delete.png\"></a>
                      </td>";
                $i = $statement->columnCount();
            }
        }
        echo "</tr>";
    }
    echo "</table>";
}

echo "<p><a href='assistman.php'><img src='/AssistApp/img/assistancenew.png'/>New assistance</a></p>";

$app->foot();
?>
