<?php
include_once ('app.php');
global $app;
$app = new App();
$app->start_session();
$app->head("AssistApp - Nurse Assistance", "AssistApp Management Utility", "Nurse Assistance Management");
$app->nav();

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (!isset($_GET['id_pat']) || !isset($_GET['id_nur'])) {     //We want to add a new assistance record
        $statementPat = $app->getAllPatientsNames();
        $statementNur = $app->getAllNursesNames();
        if (!$statementNur || !$statementPat) {         // If there was a problem retrieving the names
            echo "<p>Problem retrieving patients and nurses information</p>";
        } else {        // If there was no problem
            $dataPat = $statementPat->fetchAll();
            $dataNur = $statementNur->fetchAll();

            // Form to add a new assistance
            echo "<form method='POST' action='" . $_SERVER['PHP_SELF'] . "' class='form-signin'>";
            echo "<select name='patient' required class='form-control'>";
            echo "<option selected disabled>Patient</option>";
            foreach ($dataPat as $row) {    // We populate the ComboBox with patient names
                echo "<option value=\"".$row['id']."\">".$row['name']."</option>";
            }
            echo "</select>";
            echo "<select name='nurse' required class='form-control'>";
            echo "<option selected disabled>Nurse</option>";
            foreach ($dataNur as $row) {    // We populate the ComboBox with nurse names
                echo "<option value=\"".$row['id']."\">".$row['name']."</option>";
            }
            echo "</select>";
            echo "<input type='submit' value='Add' class=\"btn btn-lg btn-success btn-block\"/>";
            echo "</form>";
        }
    } else {        //We want to delete an existing assistance
        if ($app->deleteAssistance($_GET['id_pat'], $_GET['id_nur'])) {     // If it deleted correctly, we redirect to the assistance list
            header('Location: assist.php');
        } else {                            // Else, we show the error
            $app->showErrorConnection();
        }
    }
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {     // We want to insert assistance
    $id_pat = $_POST['patient'];
    $id_nur = $_POST['nurse'];

    if ($app->insertAssistance($id_pat, $id_nur)) {     // If it inserted without problems, we redirect to the assistance list
        header('Location: assist.php');
    } else {                            // Else, we show the error
        $app->showErrorConnection();
    }
}
$app->foot();
?>