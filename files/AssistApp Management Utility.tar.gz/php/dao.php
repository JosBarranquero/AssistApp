<?php 
/* MySQL credentials and database */
define ("DATABASE", "AssistApp_DB");
define ("MYSQL_HOST", "mysql:dbname=".DATABASE.";host=127.0.0.1;charset=utf8");
define ("MYSQL_USER", "assistapp");
define ("MYSQL_PASSWORD", "health123");

/* Table names and its columns get defined */
define("TABLE_USER", "Users");
define("USER_DOC", "id_doc");
define("USER_PASSWORD", "password");
define("USER_NAME", "name");
define("USER_SURNAME", "surname");
define("USER_TYPE", "type");
define("TYPE_NURSE", "2");
define("TYPE_PATIENT", "1");
define("USER_IMG", "img");
define("USER_EMAIL", "email");

define("TABLE_DATA", "MedData");
define("DATA_PAT", "id_pat");
define("DATA_SEX", "sex");
define("DATA_NATIONALITY", "nationality");
define("DATA_RESIDENCE", "residence");
define("DATA_JOB", "job");
define("DATA_SMOKER", "smoker");
define("DATA_ALCOHOL", "alcohol");
define("DATA_DRUGS", "drugs");

define("TABLE_RECORD", "MedRecord");
define("RECORD_DATA", "id_data");
define("RECORD_REASON", "reason");
define("RECORD_ANTECEDENTS", "antecedents");
define("RECORD_HOSPITALISED", "hospitalised");
define("RECORD_DATE", "date");

define("TABLE_ASSIST", "assists");
define("ASSIST_PAT", "id_pat");
define("ASSIST_NUR", "id_nur");

class AssistAppDao {
    protected $conn;
    protected $error;

    /* A database connection object is created by the class constructor and all remaining data gets initialised */
    function __construct() {
        try {
            $this->conn = new PDO(MYSQL_HOST, MYSQL_USER, MYSQL_PASSWORD);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            $this->error = "Connection error: ".$e->getMessage();
            $this->conn = null;
        }
    }

    function __destruct() {
        if ($this->isConnected()) {
            $this->conn = null;
        }
    }

    /* Getter for $error */
    function getError() {
        return $this->error;
    }

    /* This function checks whether there is a connection to the MySQL server */
    function isConnected() {
        return (!($this->conn == null));
    }

    /* This function executes SQL statements */
    private function execute($sql) {
        $statement = $this->conn->query($sql);
        if (!$statement) {
            $this->error = "Data statement error";
        }
        return $statement;
    }

    /* This function prepares SQL statements to be executed */
    private function prepareSql($sql) {
        $statement = $this->conn->prepare($sql);
        if (!$statement) {
            $this->error = "Data statement error";
        }
        return $statement;
    }



    /* Method which returns all the users */
    function getAllUsers() {
        $sql = "SELECT ".USER_DOC.", ".USER_NAME.", ".USER_SURNAME.", ".USER_TYPE.", ".USER_IMG.", ".USER_EMAIL.", id FROM ".TABLE_USER." ORDER BY id";
        return $this->execute($sql);
    }

    /* Function which returns all the patients names */
    function getAllPatientsNames() {
        $sql = "SELECT id, CONCAT(".USER_DOC.", ' - ', ".USER_NAME.", ' ', ".USER_SURNAME.") AS name FROM ".TABLE_USER." WHERE ".USER_TYPE." = ".TYPE_PATIENT;
        return $this->execute($sql);
    }

    /* Function which returns all the nurses names */
    function getAllNursesNames() {
        $sql = "SELECT id, CONCAT(".USER_DOC.", ' - ', ".USER_NAME.", ' ', ".USER_SURNAME.") AS name FROM ".TABLE_USER." WHERE ".USER_TYPE." = ".TYPE_NURSE;
        return $this->execute($sql);
    }

    /* Method which gets the user id */
    function getUserByDoc($id_doc)
    {
        $sql = "SELECT id, ".USER_DOC.", ".USER_NAME.", ".USER_SURNAME.", ".USER_TYPE.", ".USER_IMG.", ".USER_EMAIL." FROM " . TABLE_USER . " WHERE " . USER_DOC . "='" . $id_doc . "'";
        return $this->execute($sql);
    }

    function getUserDocById($id)  {
        $sql = "SELECT " . USER_DOC . " FROM " . TABLE_USER . " WHERE id = $id";
        $statement = $this->execute($sql);
        return $statement->fetch()[USER_DOC];
    }

    /* This function checks if a user already exists in our database */
    function containsUser($doc) {
        $sql = "SELECT * FROM ".TABLE_USER." WHERE ".USER_DOC." = '$doc'";
        $statement = $this->execute($sql);

        if ($statement->rowCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    /* This function inserts a new User in the database */
    function insertUser($doc, $pass, $name, $surname, $type, $img, $email) {
        $inserted = false;
        if (!$this->containsUser($doc)) {
            try {
                $sql = "INSERT INTO " . TABLE_USER . " (" . USER_DOC . ", " . USER_PASSWORD . ", " . USER_NAME . ", " . USER_SURNAME . ", " . USER_TYPE . ", " . USER_IMG . ", " . USER_EMAIL . ") SELECT :doc, SHA2(:pass, 256), :name, :surname, :type, :img, :email";
                $statement = $this->prepareSql($sql);
                $statement->bindParam(":doc", $doc);
                $statement->bindParam(":pass", $pass);
                $statement->bindParam(":name", $name);
                $statement->bindParam(":surname", $surname);
                $statement->bindParam(":type", $type);
                $statement->bindParam(":img", $img);
                $statement->bindParam(":email", $email);
                $inserted = $statement->execute();;
            } catch (PDOException $e) {
                $this->error = $e->getMessage();
            }
        }
        return $inserted;
    }

    /* This function updates an existing user */
    function updateUser($oldid, $doc, $pass, $name, $surname, $type, $img, $email) {
        $updated = false;
        try {
            $sql = "UPDATE ".TABLE_USER." SET ".USER_DOC." = :doc, ".USER_PASSWORD." = SHA2(:pass, 256), ".USER_NAME." = :name, ".USER_SURNAME." = :surname, ".USER_TYPE." = :type, ".USER_IMG." = :img, ".USER_EMAIL." = :email WHERE id = :oldid";
            $statement = $this->prepareSql($sql);
            $statement->bindParam(":doc", $doc);
            $statement->bindParam(":pass", $pass);
            $statement->bindParam(":name", $name);
            $statement->bindParam(":surname", $surname);
            $statement->bindParam(":type", $type);
            $statement->bindParam(":img", $img);
            $statement->bindParam(":email", $email);
            $statement->bindParam(":oldid", $oldid);
            $updated = $statement->execute();
        } catch (PDOException $e) {
            $this->error = $e->getMessage();
        }
        return $updated;
    }

    /* This function checks if the credentials entered in the login screen are correct */
    function checkUser($id_doc, $password) {
        $sql = "SELECT * FROM ".TABLE_USER." WHERE ".USER_DOC." = '$id_doc' AND ".USER_PASSWORD." = SHA2('$password', 256)";
        $statement = $this->execute($sql);

        if ($statement->rowCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    /* This function checks if the user is a nurse */
    public function checkPrivileges($id_doc) {
        $sql = "SELECT * FROM ".TABLE_USER." WHERE ".USER_DOC." = '$id_doc' AND ".USER_TYPE." = ".TYPE_NURSE;
        $statement = $this->execute($sql);

        if ($statement->rowCount() > 0) {
            return true;
        } else {
            return false;
        }
    }



    /* This function gets all the medical data from our database */
    function getAllMedData() {
        $sql = "SELECT p.".USER_DOC.", p.".USER_NAME.", p.".USER_SURNAME.", d.".DATA_SEX.", d.".DATA_NATIONALITY.", d.".DATA_RESIDENCE.", d.".DATA_JOB." as occupation, d.".DATA_SMOKER.", d.".DATA_ALCOHOL.", d.".DATA_DRUGS.", d.id FROM ".TABLE_DATA." d INNER JOIN ".TABLE_USER." p ON d.".DATA_PAT."=p.id";
        return $this->execute($sql);
    }

    /* This function returns all the patients name with Medical Data registered */
    function getAllMedDataNames() {
        $sql = "SELECT d.id, CONCAT(p.".USER_DOC.", ' - ', p.".USER_NAME.", ' ', p.".USER_SURNAME.") AS name FROM ".TABLE_DATA." d INNER JOIN ".TABLE_USER." p ON d.".DATA_PAT." = p.id";
        return $this->execute($sql);
    }

    /* This function returns a Medical Data entry by its ID */
    function getDataById($id) {
        $sql = "SELECT ".DATA_SEX.", ".DATA_NATIONALITY.", ".DATA_RESIDENCE.", ".DATA_JOB.", ".DATA_SMOKER.", ".DATA_ALCOHOL.", ".DATA_DRUGS." FROM " . TABLE_DATA . " WHERE id = " . $id;
        return $this->execute($sql);
    }

    /* This function inserts new Medical Data in the database */
    function insertData($pat, $sex, $nationality, $residence, $job, $smoker, $alcohol, $drugs) {
        $inserted = false;
        try {
            $sql = "INSERT INTO ".TABLE_DATA." (".DATA_PAT.", ".DATA_SEX.", ".DATA_NATIONALITY.", ".DATA_RESIDENCE.", ".DATA_JOB.", ".DATA_SMOKER.", ".DATA_ALCOHOL.", ".DATA_DRUGS.") VALUES (:pat, :sex, :nationality, :residence, :job, :smoker, :alcohol, :drugs)";
            $statement = $this->prepareSql($sql);
            $statement->bindParam(":pat", $pat);
            $statement->bindParam(":sex", $sex);
            $statement->bindParam(":nationality", $nationality);
            $statement->bindParam(":residence", $residence);
            $statement->bindParam(":job", $job);
            $statement->bindParam(":smoker", $smoker);
            $statement->bindParam(":alcohol", $alcohol);
            $statement->bindParam(":drugs", $drugs);
            $inserted = $statement->execute();
        } catch (PDOException $e) {
            $this->error = $e->getMessage();
        }
        return $inserted;
    }

    /* This function updates existing Medical Data */
    function updateData($oldid, $sex, $nationality, $residence, $job, $smoker, $alcohol, $drugs) {
        $updated = false;
        try {
            $sql = "UPDATE ".TABLE_DATA." SET ".DATA_SEX." = :sex, ".DATA_NATIONALITY." = :nationality, ".DATA_RESIDENCE." = :residence, ".DATA_JOB." = :job, ".DATA_SMOKER." = :smoker, ".DATA_ALCOHOL." = :alcohol, ".DATA_DRUGS." = :drugs WHERE id = :oldid";
            $statement = $this->prepareSql($sql);
            $statement->bindParam(":sex", $sex);
            $statement->bindParam(":nationality", $nationality);
            $statement->bindParam(":residence", $residence);
            $statement->bindParam(":job", $job);
            $statement->bindParam(":smoker", $smoker);
            $statement->bindParam(":alcohol", $alcohol);
            $statement->bindParam(":drugs", $drugs);
            $statement->bindParam(":oldid", $oldid);
            $updated = $statement->execute();
        } catch (PDOException $e) {
            $this->error = $e->getMessage();
        }
        return $updated;
    }



    /* This function gets all the medical record from the database */
    function getAllMedRecord() {
        $sql = "SELECT CONCAT(p.".USER_DOC.", ' - ', p.".USER_NAME.", ' ', p.".USER_SURNAME.") AS patient, r.".RECORD_REASON.", r.".RECORD_ANTECEDENTS.", r.".RECORD_HOSPITALISED.", r.".RECORD_DATE.", r.id FROM ".TABLE_RECORD." r INNER JOIN ".TABLE_DATA." d ON r.".RECORD_DATA." = d.id INNER JOIN ".TABLE_USER." p ON d.".DATA_PAT." = p.id ORDER BY r.".RECORD_DATA;
        return $this->execute($sql);
    }

    /* This function adds a new assistance record */
    function insertRecord($data, $reason, $antecedents, $hospitalised) {
        $inserted = false;
        try {
            $sql = "INSERT INTO ".TABLE_RECORD."(".RECORD_DATA.", ".RECORD_REASON.", ".RECORD_ANTECEDENTS.", ".RECORD_HOSPITALISED.", ".RECORD_DATE.") SELECT :data, :reason, :antecedents, :hospitalised, NOW()";
            $statement = $this->prepareSql($sql);
            $statement->bindParam(":data", $data);
            $statement->bindParam(":reason", $reason);
            $statement->bindParam(":antecedents", $antecedents);
            $statement->bindParam(":hospitalised", $hospitalised);
            $inserted = $statement->execute();
        } catch (PDOException $e) {
            $this->error = $e->getMessage();
        }
        return $inserted;
    }

    /* This function deletes an existing assistance record */
    function deleteMedRecord($id) {
        $deleted = false;
        try {
            $sql = "DELETE FROM ".TABLE_RECORD." WHERE id = :id";
            $statement = $this->prepareSql($sql);
            $statement->bindParam(":id", $id);
            $deleted = $statement->execute();
        } catch (PDOException $e) {
            $this->error = $e->getMessage();
        }
        return $deleted;
    }



    /* This function gets all the nurses assistance */
    public function getAllAssistance() {
        $sql = "SELECT CONCAT(n.".USER_DOC.", ' - ', n.".USER_NAME.", ' ', n.".USER_SURNAME.") AS nurse, CONCAT(p.".USER_DOC.", ' - ', p.".USER_NAME.", ' ', p.".USER_SURNAME.") AS patient, a.".ASSIST_PAT.", a.".ASSIST_NUR." FROM ".TABLE_ASSIST." a INNER JOIN ".TABLE_USER." n ON a.".ASSIST_NUR." = n.id INNER JOIN ".TABLE_USER." p ON a.".ASSIST_PAT." = p.id";
        return $this->execute($sql);
    }

    /* This function adds a new assistance record */
    function insertAssistance($id_pat, $id_nur) {
        $inserted = false;
        try {
            $sql = "INSERT INTO ".TABLE_ASSIST." VALUES (:id_pat, :id_nur)";
            $statement = $this->prepareSql($sql);
            $statement->bindParam(":id_pat", $id_pat);
            $statement->bindParam(":id_nur", $id_nur);
            $inserted = $statement->execute();
        } catch (PDOException $e) {
            $this->error = $e->getMessage();
        }
        return $inserted;
    }

    /* This function deletes an existing assistance record */
    function deleteAssistance($id_pat, $id_nur) {
        $deleted = false;
        try {
            $sql = "DELETE FROM ".TABLE_ASSIST." WHERE ".ASSIST_PAT." = :id_pat AND ".ASSIST_NUR." = :id_nur";
            $statement = $this->prepareSql($sql);
            $statement->bindParam(":id_pat", $id_pat);
            $statement->bindParam(":id_nur", $id_nur);
            $deleted = $statement->execute();
        } catch (PDOException $e) {
            $this->error = $e->getMessage();
        }
        return $deleted;
    }
}
?>
