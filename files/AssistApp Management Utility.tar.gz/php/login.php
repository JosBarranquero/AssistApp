<?php 
include_once('app.php');
session_start();
global $app;
$app = new App();
if ($app->isLogged())       // If the user is logged in, he/she gets redirected to the users list
    header('Location: ./users.php');
$app->head("AssistApp - Login", "AssistApp Management Utility" ,"Login");
$app->nav();
?>

<!-- Form to log in -->
<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST" class="form-signin">
    <input type="text"  placeholder="ID document number" name="id" maxlength="9" required autofocus class="form-control"/>
    <input type="password"  placeholder="Password" name="password" required class="form-control"/>
    
    <input type="submit" class="btn btn-lg btn-primary btn-block" value="Login"/>
</form>
<?php 
if ($_SERVER['REQUEST_METHOD'] == "POST") {  /* This gets executed when the form is submitted */
    $id_doc = $_POST['id'];
    $password = $_POST['password'];

    if (!($app->isConnected())) {
        $app->showErrorConnection();
    } else {
        if ($app->checkUser($id_doc, $password)) {  // If the user and password are correct...
            if ($app->checkPrivileges($id_doc)) {   // And the user is a nurse, it redirects the user to the users list
                $app->init_session($id_doc);
                header('Location: ./users.php');
            } else {                                // Else, an unauthorized user error message shows
                echo "<p>Unauthorized user</p>";
            }
        } else {    // If the credentials are incorrect, a message shows
            echo "<p>Incorrect ID or password</p>";
        }
    }
}

$app->foot();
?>
