<?php
include_once ('app.php');
global $app;
$app = new App();
$app->start_session();
$app->head("AssistApp - Medical Data", "AssistApp Management Utility", "Medical Data Management");
$app->nav();

if (isset($_GET['query'])) {    //If 'query' is set, this means we want to search for something
    $statement = $app->searchData($_GET['query']);
} else {                        //Else, we just want the complete listing
    $statement = $app->getAllMedData();
}

// Search form
echo "<form action='".$_SERVER['PHP_SELF']."' method='GET' class='form-inline'>";
echo "<input type='text' name='query' placeholder='Search query' class='form-control'/>";
echo "<input type=\"image\" src='/AssistApp/img/search.png' alt='Search' class=\"btn btn-success\"/>";
echo "</form><br/>";

if (!$statement) {  // If there was an error getting the listing, we print it
    $app->showErrorConnection();
} else if (count($result = $statement->fetchAll()) == 0) {
    echo "<p>No data...</p>";   // No data recorded in the database
} else {                            // If there is, we show a table
    echo "<table class=\"table table-striped\">";
    echo "<tr>";
    for ($i = 0; $i < $statement->columnCount(); $i++) {
        $columnMeta = $statement->getColumnMeta($i);
        echo "<th>".$columnMeta['name']."</th>";
        if ($i == $statement->columnCount()-2) {   // We add another column at the last position
            echo "<th>edit</th>";
            $i = $statement->columnCount();
        }
    }
    echo "</tr>";

    foreach ($result as $row) {
        echo "<tr>";
        for ($i=0; $i < $statement->columnCount(); $i++) {
            $content = $row[$i];
            if ($content == "1") {
                $content = "<img src='/AssistApp/img/yes.png'/>";
            }
            if ($content == "0") {
                $content = "<img src='/AssistApp/img/no.png'/>";
            }
            echo "<td>".$content."</td>";
            if ($i == $statement->columnCount()-2) {    /* We add the edit button in the last column */
                echo "<td>
                        <a href=\"meddataman.php?id=".$row['id']."\"><img src=\"/AssistApp/img/edit.png\"></a>
                      </td>";
                $i = $statement->columnCount();
            }
        }
        echo "</tr>";
    }
    echo "</table>";

}

echo "<p><a href='meddataman.php'><img src='/AssistApp/img/medrecorddrawer.png'/>Add new data</a></p>";

$app->foot();
?>