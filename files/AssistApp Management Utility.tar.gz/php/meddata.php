<?php
include_once ('app.php');
global $app;
$app = new App();
$app->start_session();
$app->head("AssistApp - Medical Data", "AssistApp Management Utility", "Medical Data Management");
$app->nav();

$statement = $app->getAllMedData();

if (!$statement) {
    $app->showErrorConnection();
} else if (count($result = $statement->fetchAll()) == 0) {
    echo "<p>No data...</p>";   /* No data recorded in the database */
} else {
    echo "<img src=\"/AssistApp/img/search.png\"/>Search by pressing Control + F simultaneously<br/>";

    echo "<table class=\"table table-striped\">";
    echo "<tr>";
    for ($i = 0; $i < $statement->columnCount(); $i++) {
        $columnMeta = $statement->getColumnMeta($i);
        echo "<th>".$columnMeta['name']."</th>";
        if ($i == $statement->columnCount()-2) {   /* We add another column at the last position */
            echo "<th>edit</th>";
            $i = $statement->columnCount();
        }
    }
    echo "</tr>";

    foreach ($result as $row) {
        echo "<tr>";
        for ($i=0; $i < $statement->columnCount(); $i++) {
            echo "<td>".$row[$i]."</td>";
            if ($i == $statement->columnCount()-2) {    /* We add the edit button in the last column */
                echo "<td>
                        <a href=\"meddataman.php?id=".$row['id']."\"><img src=\"/AssistApp/img/edit.png\"></a>
                      </td>";
                $i = $statement->columnCount();
            }
        }
        echo "</tr>";
    }
    echo "</table>";

}

echo "<p><a href='meddataman.php'><img src='/AssistApp/img/meddatasheet.png'/>Add new data</a></p>";

$app->foot();
?>