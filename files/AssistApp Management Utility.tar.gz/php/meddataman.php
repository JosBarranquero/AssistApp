<?php
include_once ('app.php');
global $app;
$app = new App();
$app->start_session();
$app->head("AssistApp - Medical Data", "AssistApp Management Utility", "Medical Data Management");
$app->nav();

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['id'])) {   // We want to edit existing data
        $statement = $app->getDataById($_GET['id']);
        if (!$statement) { //if data doesn't exists
            header('Location: meddata.php');
        } else {
            $data = $statement->fetch();
            echo "<form action='" . $_SERVER['PHP_SELF'] . "' method='POST' class='form-signin'>";
            echo "<select name=\"sex\" class=\"form-control\" required>
                    <option disabled>Sex</option>";
            if ($data['sex'] == "m") {
                echo "<option value='1' selected>Male</option>";
                echo "<option value='2'>Female</option>";
            } else {
                echo "<option value='1'>Male</option>";
                echo "<option value='2' selected>Female</option>";
            }
            echo "<input type=\"text\" name=\"nationality\" maxlength=\"30\" placeholder=\"Nationality\" class=\"form-control\" value='".$data['nationality']."' required/>";
            echo "<input type=\"date\" name=\"birthdate\" min=\"1900-01-01\" required class=\"form-control\" value='".$data['birthdate']."'/>";
            echo "<input type='text' name='residence' maxlength=\"100\" placeholder='Residence' class='form-control' value='".$data['residence']."' required/>";
            echo "<input type='text' name='job' maxlength=\"30\" placeholder='Occupation' class='form-control' value='".$data['job']."' required/>";
            if ($data['smoker'] == 1) {
                echo "<input type='checkbox' name='smoker' value='true' checked/>Smoker";
            } else {
                echo "<input type='checkbox' name='smoker' value='true'/>Smoker";
            }
            if ($data['alcohol'] == 1) {
                echo "<input type='checkbox' name='alcohol' value='true' checked/>Alcohol";
            } else {
                echo "<input type='checkbox' name='alcohol' value='true'/>Alcohol";
            }
            if ($data['drugs'] == 1) {
                echo "<input type='checkbox' name='drugs' value='drugs' checked/>Drugs";
            } else {
                echo "<input type='checkbox' name='drugs' value='drugs'/>Drugs";
            }
            echo "<input type='hidden' name='id' value='".$_GET['id']."'/>";
            echo "<input type='submit' value='Edit' class=\"btn btn-lg btn-success btn-block\"/>
               </form>";
        }
    } else {    // We want to add new data
        $statement = $app->getAllPatientsNames();
        if (!$statement) {
            $app->showErrorConnection();
        } else {
            $result = $statement->fetchAll();
            echo "<form action=\"".$_SERVER['PHP_SELF']."\" method=\"POST\" class=\"form-signin\">
                    <select name=\"id_pat\" class=\"form-control\" required>
                        <option disabled selected>Patient</option>";
            foreach ($result as $row) {
                echo "<option value=\"".$row['id']."\">".$row['name']."</option>";
            }
            echo "</select>";
            echo "<select name=\"sex\" class=\"form-control\" required>
                    <option disabled selected>Sex</option>
                    <option value='1'>Male</option>
                    <option value='2'>Female</option>
                   </select>";
            echo "<input type=\"text\" name=\"nationality\" maxlength=\"30\" placeholder=\"Nationality\" class=\"form-control\" required/>";
            echo "<input type=\"date\" name=\"birthdate\" min=\"1900-01-01\" required class=\"form-control\"/>";
            echo "<input type='text' name='residence' maxlength=\"100\" placeholder='Residence' class='form-control' required/>";
            echo "<input type='text' name='job' maxlength=\"30\" placeholder='Occupation' class='form-control' required/>";
            echo "<input type='checkbox' name='smoker' value='true'/>Smoker";
            echo "<input type='checkbox' name='alcohol' value='true'/>Alcohol";
            echo "<input type='checkbox' name='drugs' value='drugs'/>Drugs";
            echo "<input type='hidden' name='id' value='0'/>";
            echo "<input type='submit' value='Add' class=\"btn btn-lg btn-success btn-block\"/>
               </form>";
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {     //When the form is submitted
    if ($_POST['id'] == 0) {    // New data
        $pat = $_POST['id_pat'];
        $sex = $_POST['sex'];
        $nationality = $_POST['nationality'];
        $birthdate = $_POST['birthdate'];
        $residence = $_POST['residence'];
        $job = $_POST['job'];
        $smoker = isset($_POST['smoker']);
        $alcohol = isset($_POST['alcohol']);
        $drugs = isset($_POST['drugs']);

        if ($app->insertData($pat, $sex, $nationality, $birthdate, $residence, $job, $smoker, $alcohol, $drugs)) {
            header('Location: meddata.php');
        } else {
            $app->showErrorConnection();
        }
    } else {    // Editing existing data
        $sex = $_POST['sex'];
        $nationality = $_POST['nationality'];
        $birthdate = $_POST['birthdate'];
        $residence = $_POST['residence'];
        $job = $_POST['job'];
        $smoker = isset($_POST['smoker']);
        $alcohol = isset($_POST['alcohol']);
        $drugs = isset($_POST['drugs']);
        $id = $_POST['id'];

        if ($app->updateData($id, $sex, $nationality, $birthdate, $residence, $job, $smoker, $alcohol, $drugs)) {
            header('Location: meddata.php');
        } else {
            $app->showErrorConnection();
        }
    }
}

$app->foot();
?>
