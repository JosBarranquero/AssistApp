<?php
include_once('app.php');
global $app;
$app = new App();
$app->start_session();
$app->head("AssistApp - Medical Record", "AssistApp Management Utility", "Medical Record Management");
$app->nav();

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['id'])) {   //If it's set, we want to delete a record
        if ($app->deleteMedRecord($_GET['id'])) {
            header('Location: medrecord.php');
        } else {
            $app->showErrorConnection();
        }
    } else {    // Else, we want to add a new one
        $statement = $app->getAllMedDataNames();
        if (!$statement) {
            $app->showErrorConnection();
        } else {
            $result = $statement->fetchAll();
            echo "<form action=\"" . $_SERVER['PHP_SELF'] . "\" method=\"POST\" class=\"form-signin\">";
            echo "<select name=\"id_data\" class=\"form-control\" required>
                        <option disabled selected>Patient</option >";
            foreach ($result as $row) {
                echo "<option value=\"" . $row['id'] . "\">" . $row['name'] . "</option>";
            }
            echo "</select>";
            echo "<input type='text' maxlength='75' name='reason' placeholder='Reason' class='form-control' required/>";
            echo "<input type='text' maxlength='140' name='antecedents' placeholder='Antecedents' class='form-control' required/>";
            echo "<input type='checkbox' name='hospitalised' value='true'/>Hospitalised";
            //echo "<input type='hidden' name='id' value='0'/>";
            echo "<input type='submit' value='Add' class=\"btn btn-lg btn-success btn-block\"/>
               </form>";
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = $_POST['id_data'];
    $reason = $_POST['reason'];
    $antecedents = $_POST['antecedents'];
    $hospitalised = isset($_POST['hospitalised']);

    if ($app->insertRecord($data, $reason, $antecedents, $hospitalised)) {
        header('Location: medrecord.php');
    } else {
        $app->showErrorConnection();
    }
}

$app->foot();
?>