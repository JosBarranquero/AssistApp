<?php
include_once('app.php');
global $app;
$app = new App();
$app->head("AssistApp - Password restore", "AssistApp", "Password restore");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $pass = $_POST['pass'];
    $pass2 = $_POST['pass2'];
    $idDoc = $_POST['idDoc'];
    $hash = $_POST['hash'];

    if (!strcmp($pass, $pass2) == 0) {
        header("Location: pass.php?idDoc=" . $idDoc . "&hash=" . $hash . "&message=unmatch");
    } else {
        if (!$app->checkPass($pass)) {
            header("Location: pass.php?idDoc=" . $idDoc . "&hash=" . $hash . "&message=invalid");
        } else {
            if ($app->updatePass($pass, $idDoc, $hash)) {
                header("Location: pass.php?idDoc=" . $idDoc . "&hash=" . $hash . "&message=valid");
            } else {
                header("Location: pass.php?idDoc=" . $idDoc . "&hash=" . $hash . "&message=error");
            }
        }
    }
}
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (!isset($_GET['idDoc']) || !isset($_GET['hash'])) {
        header('Location: login.php');
    }

    echo "<div id=\"content\"><center>";

    if (isset($_GET['message'])) {
        switch ($_GET['message']) {
            case 'valid':
                echo "<p>Password changed succesfully</p>";
                break;
            case 'error':
                echo "<p>Error changing password. Please, try again later</p>";
                break;
	    case 'invalid':
                echo "<p>The password must be at least 8 characters long and contain a combination of alphanumeric characters</p>";
                break;
            case 'unmatch':
                echo "<p>Passwords don't match</p>";
                break;
        }
    } else {
        echo "<form action='" . $_SERVER['PHP_SELF'] . "' method='POST' class='form-signin'>";
        echo "<input type='password' name='pass' placeholder='Password' class='form-control'/>";
        echo "<input type='password' name='pass2' placeholder='Confirm password' class='form-control'/>";
        echo "<input type='hidden' name='idDoc' value='" . $_GET['idDoc'] . "'/>";
        echo "<input type='hidden' name='hash' value='" . $_GET['hash'] . "'/>";
        echo "<input type='submit' value='Restore' class='btn btn-lg btn-success btn-block'/>";
        echo "</form>";
    }
}

$app->foot();
?>
