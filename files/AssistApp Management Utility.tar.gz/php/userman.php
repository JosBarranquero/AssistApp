<?php
include_once('app.php');
global $app;
$app = new App();
$app->start_session();
$app->head("AssistApp - Users", "AssistApp Management Utility", "User Management");
$app->nav();

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['id'])) {
        $doc = $app->getUserDocById($_GET['id']);

        $statement = $app->getUserByDoc($doc);
        if (!$statement) {  //if the user doesn't exist
            header('Location: users.php');
        } else {
            $result = $statement->fetchAll();

            echo "<form action=\"" . $_SERVER['PHP_SELF'] . "\" method=\"POST\" class=\"form-signin\" enctype=\"multipart/form-data\">
            <input type=\"password\" name=\"pass\" placeholder=\"Password\" class=\"form-control\"/>
            <input type=\"text\" name=\"name\" placeholder=\"Name\" value=\"" . $result[0][USER_NAME] . "\" required maxlength=\"25\" class=\"form-control\"/>
            <input type=\"text\" name=\"surname\" placeholder=\"Surname\" value=\"" . $result[0][USER_SURNAME] . "\" required maxlength=\"45\" class=\"form-control\"/>
            <select name=\"type\" required class=\"form-control\">
                <option disabled>Type</option>";
            if ($result[0][USER_TYPE] == "patient") {
                echo "<option selected value = \"1\">Patient</option>
                <option value=\"2\">Nurse</option>";
            } else {
                echo "<option value = \"1\">Patient</option>
                <option selected value=\"2\">Nurse</option>";
            }
            echo "</select>
            <input type=\"file\" name=\"img\" id=\"img\" class=\"form-control\" accept=\"image/jpeg|image/png|image/gif\"/>
             <input type=\"email\" name=\"email\" placeholder=\"Email\" value=\"" . $result[0][USER_EMAIL] . "\" class=\"form-control\" maxlength=\"40\" required/>
            <input type=\"hidden\" name=\"oldid\" value=\"" . $_GET['id'] . "\"/>
            <input type=\"submit\" value=\"Edit\" class=\"btn btn-lg btn-success btn-block\"/>
        </form>";
        }
    } else {
        ?>

        <!-- Form to add new users -->
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" class="form-signin"
              enctype="multipart/form-data">
            <input type="text" name="id_doc" maxlength="9" placeholder="ID document number" class="form-control"
                   required autofocus/>
            <input type="password" name="pass" placeholder="Password" class="form-control" required/>
            <input type="text" name="name" placeholder="Name" maxlength="25" class="form-control" required/>
            <input type="text" name="surname" placeholder="Surname" maxlength="45" class="form-control" required/>
            <select name="type" required class="form-control">
                <option selected disabled>Type</option>
                <option value="1">Patient</option>
                <option value="2">Nurse</option>
            </select>
            <input type="file" name="img" id="img" class="form-control" accept="image/jpeg|image/png|image/gif"
                   required/>
            <input type="email" name="email" placeholder="Email" maxlength="40" class="form-control" required/>
            <input type="hidden" name="oldid" value="0"/>
            <input type="submit" value="Add" class="btn btn-lg btn-success btn-block"/>
        </form>
        <?php
    }
}
if ($_SERVER['REQUEST_METHOD'] == "POST") { /* This gets executed when the form is submitted */
    if ($_POST['oldid'] == 0) { // This means it's a new user
        if (!$app->checkPass($pass = $_POST['pass'])) {
            echo "<p>The password must be at least 8 characters long and contain a combination of alphanumeric characters</p>";
        }
        if (!$app->containsUser($id_doc = $_POST['id_doc'])) {
            if (!$app->upload($_FILES["img"])) {
                echo "<p>There was a problem uploading the user image.<br/>The image must be in jpg, png or gif format, and less than 64KB.<br/>If the above requirements are met, please try changing its name.</p>";
            } else {
                $name = $_POST['name'];
                $surname = $_POST['surname'];
                $type = $_POST['type'];
                $img = "profiles/" . $_FILES["img"]["name"];
                $email = $_POST['email'];

                if ($app->insertUser($id_doc, $pass, $name, $surname, $type, $img, $email)) {   //If it inserted correctly, the user is redirected to the Users list
                    header('Location: users.php');
                } else {
                    $app->showErrorConnection();
                }
            }
        } else {
            echo "<p>User with same ID document number registered</p>";
        }
    } else {    // Else, we are editing an existing user with an id
        if (isset($_POST['pass'])) {
            if (!$app->checkPass($pass = $_POST['pass'])) {
                echo "<p>The password must be at least 8 characters long and contain a combination of alphanumeric characters</p>";
            }
        } else {
            $pass = null;
        }
        if (isset($_FILES['img'])) {
            if ($app->upload($_FILES['img'])) {
                $img = "profiles/" . $_FILES["img"]["name"];
            } else {
                echo "<p>There was a problem uploading the user image.<br/>The image must be in jpg, png or gif format, and less than 64KB.<br/>If the above requirements are met, please try changing its name.</p>";
                $img = null;
            }
        } else {
            $img = null;
        }
        $oldid = $_POST['oldid'];
        $name = $_POST['name'];
        $surname = $_POST['surname'];
        $type = $_POST['type'];
        $email = $_POST['email'];

        if ($app->updateUser($oldid, $pass, $name, $surname, $type, $img, $email)) {   //If it updated correctly, the user is redirected to the Users list
            header('Location: users.php');
        } else {
            $app->showErrorConnection();
        }
    }
}
$app->foot();
?>