<?php
include_once('app.php');
global $app;
$app = new App();
$app->start_session();
$app->head("AssistApp - Users", "AssistApp Management Utility", "User Management");
$app->nav();

if (isset($_GET['query'])) {
    $statement = $app->searchUser($_GET['query']);
} else {
    $statement = $app->getAllUsers();
}

echo "<form action='".$_SERVER['PHP_SELF']."' method='GET' class='form-signin'>";
echo "<input type='text' name='query' placeholder='Search query' class='form-control'/>";
echo "<input type=\"image\" src='/AssistApp/img/search.png' alt='Search' class=\"btn btn-success\"/>";
echo "</form>";

if (!$statement) {
    $app->showErrorConnection();
} else if (count($result = $statement->fetchAll()) == 0) {
    echo "<p>No users...</p>";   /* No users */
} else {
    echo "<table class=\"table table-striped\">";
    echo "<tr>";
    for ($i = 0; $i < $statement->columnCount(); $i++) {
        $columnMeta = $statement->getColumnMeta($i);
        echo "<th>".$columnMeta['name']."</th>";
        if ($i == $statement->columnCount()-2) {   /* We add another column at the last position */
            echo "<th>edit</th>";
            $i = $statement->columnCount();
        }
    }
    echo "</tr>";

    foreach ($result as $row) {
        echo "<tr>";
        for ($i=0; $i < $statement->columnCount(); $i++) {
            echo "<td>".$row[$i]."</td>";
            if ($i == $statement->columnCount()-2) {    /* We add the edit button in the last column */
                echo "<td>
                        <a href=\"userman.php?id=".$row['id']."\"><img src=\"/AssistApp/img/edit.png\"></a>
                      </td>";
                $i = $statement->columnCount();
            }
        }
        echo "</tr>";
    }
    echo "</table>";

    echo "<p><nav>
    				    <ul>
							<li><a href='userman.php'><img src='/AssistApp/img/user.png'/>Add new user</a></li>
        				</ul>
    			 </nav></p>";
}
$app->foot();
?>

