<?php 
include_once('app.php');
global $app;
$app = new App();
$app->start_session();
$app->head("AssistApp - Users", "AssistApp Management Utility", "User Management");
$app->nav();

$statement = $app->getAllUsers();

if (!$statement) {
    $app->showErrorConnection();
} else if (count($result = $statement->fetchAll()) == 0) {
    echo "<p>No users...</p>";   /* This should not appear */
} else {
    echo "<img src=\"/AssistApp/img/search.png\"/>Search by pressing Control + F simultaneously<br/>";

    echo "<table class=\"table table-striped\">";
    echo "<tr>";
    for ($i = 0; $i < $statement->columnCount(); $i++) {
        $columnMeta = $statement->getColumnMeta($i);
        echo "<th>".$columnMeta['name']."</th>";
        if ($i == $statement->columnCount()-2) {   /* We add another column at the last position */
            echo "<th>edit</th>";
            $i = $statement->columnCount();
        }
    }
    echo "</tr>";

    foreach ($result as $row) {
        echo "<tr>";
        for ($i=0; $i < $statement->columnCount(); $i++) {
            echo "<td>".$row[$i]."</td>";
            if ($i == $statement->columnCount()-2) {    /* We add the edit button in the last column */
                echo "<td>
                        <a href=\"userman.php?id=".$row['id']."\"><img src=\"/AssistApp/img/edit.png\"></a>
                      </td>";
                $i = $statement->columnCount();
            }
        }
        echo "</tr>";
    }
    echo "</table>";

    echo "<p><a href='userman.php'><img src='/AssistApp/img/user.png'/>Add new user</a></p>";
}
$app->foot();
?>

